/**
 * scripts.js — Minisite Demo
 *
 * Lightweight vanilla JS. No frameworks, no build step.
 * Bundled alongside index.html, style.css, and hero.svg
 * then zipped and uploaded to Drupal's Minisite module.
 */

'use strict';

/* ── Intersection Observer: reveal on scroll ── */
function initReveal() {
  const targets = document.querySelectorAll('.step, .hero-image-wrap');

  if (!('IntersectionObserver' in window)) {
    // Fallback: just show everything
    targets.forEach(el => el.classList.add('visible'));
    return;
  }

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry, i) => {
        if (entry.isIntersecting) {
          // Stagger cards within a grid
          const siblings = Array.from(
            entry.target.parentElement.querySelectorAll('.step')
          );
          const idx = siblings.indexOf(entry.target);
          const delay = idx >= 0 ? idx * 80 : 0;

          setTimeout(() => {
            entry.target.classList.add('visible');
          }, delay);

          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.12, rootMargin: '0px 0px -40px 0px' }
  );

  targets.forEach(el => observer.observe(el));
}

/* ── Active nav link on scroll ─────────────── */
function initNavHighlight() {
  const sections = document.querySelectorAll('section[id]');
  const links    = document.querySelectorAll('.nav-links a[href^="#"]');

  if (!sections.length || !links.length) return;

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          links.forEach(a => a.style.color = '');
          const active = document.querySelector(
            `.nav-links a[href="#${entry.target.id}"]`
          );
          if (active) active.style.color = 'var(--accent)';
        }
      });
    },
    { threshold: 0.4 }
  );

  sections.forEach(s => observer.observe(s));
}

/* ── Smooth scroll for anchor links ────────── */
function initSmoothScroll() {
  document.querySelectorAll('a[href^="#"]').forEach(link => {
    link.addEventListener('click', e => {
      const id = link.getAttribute('href').slice(1);
      const target = document.getElementById(id);
      if (!target) return;
      e.preventDefault();
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
  });
}

/* ── Zip structure interactive demo ────────── */
function initZipDemo() {
  const btn = document.getElementById('zip-toggle');
  const tree = document.getElementById('zip-tree');
  if (!btn || !tree) return;

  const files = [
    { name: 'minisite.zip',  icon: '📦', color: '#ffbd2e', indent: 0, folder: true },
    { name: 'index.html',    icon: '🌐', color: '#00d4ff', indent: 1 },
    { name: 'files',         icon: '🗂️', color: '#f72f93', indent: 1 },
    { name: 'style.css',     icon: '🎨', color: '#7b2ff7', indent: 2 },
    { name: 'scripts.js',    icon: '⚡', color: '#28ca41', indent: 2 },
    { name: 'logo.svg',      icon: '🖼', color: '#ff6b6b', indent: 2 },
  ];

  let open = false;

  function render() {
    tree.innerHTML = '';
    const toShow = open ? files : [files[0]];

    toShow.forEach((f, i) => {
      const row = document.createElement('div');
      row.style.cssText = `
        display: flex; align-items: center; gap: 8px;
        padding: 8px 0; border-bottom: 1px solid rgba(255,255,255,0.04);
        padding-left: ${f.indent * 24}px;
        opacity: 0; animation: fadeSlideIn 0.3s ease forwards;
        animation-delay: ${i * 50}ms;
      `;

      const icon = document.createElement('span');
      icon.textContent = f.icon;
      icon.style.fontSize = '15px';

      const name = document.createElement('span');
      name.textContent = f.name;
      name.style.cssText = `
        font-family: var(--font-mono);
        font-size: 13px;
        color: ${f.color};
      `;

      row.appendChild(icon);
      row.appendChild(name);

      if (f.folder) {
        const arrow = document.createElement('span');
        arrow.textContent = open ? '▾' : '▸';
        arrow.style.cssText = 'font-size:11px; color: var(--muted); margin-left:2px;';
        row.appendChild(arrow);
      }

      tree.appendChild(row);
    });

    btn.textContent = open ? 'Collapse zip' : 'Expand zip contents';
  }

  // Inject keyframe if not present
  if (!document.querySelector('#fadeSlideInStyle')) {
    const s = document.createElement('style');
    s.id = 'fadeSlideInStyle';
    s.textContent = `
      @keyframes fadeSlideIn {
        from { opacity:0; transform:translateX(-8px); }
        to   { opacity:1; transform:translateX(0); }
      }
    `;
    document.head.appendChild(s);
  }

  btn.addEventListener('click', () => { open = !open; render(); });
  render();
}

/* ── Boot ───────────────────────────────────── */
document.addEventListener('DOMContentLoaded', () => {
  initReveal();
  initNavHighlight();
  initSmoothScroll();
  initZipDemo();
});
